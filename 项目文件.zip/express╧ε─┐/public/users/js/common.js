function getEventToObject (event){//第一个函数，将表单事件对象转化成一个正常的对象
    let object ={};
    const {elements} = event.target;
    for(let i=0;i<elements.length -1;i++)//forEach不知道为什么不能使用
    {
        if(elements[i].name==="button"){}
        else{
           object[elements[i].name]=elements[i].value;
        }
    }
    return object;
}  
