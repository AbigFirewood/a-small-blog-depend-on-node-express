//添加修改用户的路由
const joi = require("joi")//引入joi模块
///从数据库模块导入用户集合构造函数
const {User ,validateUser}=require("../../model/user");
//导入数据加密库bcriptjs 这个不需要任何依赖 用来比较密码
const bcrypt = require('bcryptjs');
const formidable = require("formidable")
const path = require("path");
const fs = require('fs');

module.exports =async function(req,res,next){
  const form = new formidable.IncomingForm();
    //配置服务器文件夹，将客户端上传的文件保存到这里这里必须写绝对路径 __dirname 是这个文件的文件夹
   form.uploadDir = path.join(__dirname,"../","../","public/","upload")
   //解系表单
   form.keepExtensions = true;
   
  //res.send(req.body);return;
    const newUser=validateUser(req.body);//使用验证函数验证
   if(newUser.error){//通过查询字符串的方式携带信息，redirect不能直接携带message
        res.redirect(`/users/user-edit?message=${newUser.error.message}`)
        return;//防止报错，终止程序 
    }else{
      //基础验证通过了,验证重复
      const user = await  User.findOne({email: req.body.email})
      if(user){res.redirect(`/users/user-edit?message=邮箱已经被注册！`); return;}//防止报错，终止程序
      const salt=await bcrypt.genSalt(10);
      const password = await bcrypt.hash(req.body.password,salt);
      req.body.password=password;
      if(await User.create(req.body)){
          res.redirect("/users/user");
      }else{
        res.status(400).render("users/error",{msg:"服务器出现了未知的错误！"})
      }
   }
}
