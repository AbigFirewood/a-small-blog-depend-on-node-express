//所有用户信息展示页面渲染路由
const {User}=require("../../model/user.js");//导入用户集合

module.exports=async function(req, res, next) {
    req.app.locals.current="user";//标记高亮
    let page = req.query.page || 1;//获得页数
    //一共有几页？
    let usernum=await User.countDocuments({})//数据的总数
    let total=Math.ceil(usernum/20);//向上取整计算总页数
    let start=(page-1)*20;//计算查询开始的位置
    let users=await User.find({}).limit(20).skip(start);//查询信息
    res.render("users/user",{
          users:users,//用户信息
          page:page,  //当前页面
          total:total,//页面总数
          usernum:usernum//用户总数
    })//提供相应的模板引擎渲染
}