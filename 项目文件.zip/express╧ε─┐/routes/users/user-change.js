const {User , validateUser} = require("../../model/user");//引入模块
//导入数据加密库bcriptjs 这个不需要任何依赖 用来比较密码
const bcrypt = require('bcryptjs');
module.exports=async function(req,res,next){
    const userID = req.query.id;//获取信息
    const userMessage=req.body; //获取信息
    let user = await User.findOne({_id:userID});//查询用户
    if(await bcrypt.compare(userMessage.password , user.password)){
      //正确的密码
      const changeUser=validateUser(userMessage);//使用验证函数验证
      if(changeUser.error){//通过查询字符串的方式携带信息，redirect不能直接携带message
        res.redirect(`/users/user-edit?id=${userID}&message=${changeUser.error.message}`)
        return;//防止报错，终止程序 
      }else{//正确的密码 正确的信息格式
        await User.updateOne({_id:userID},{//一定要使用await接受，否则会有问题！写的是要修改的，不用修改的不写
            username:userMessage.username,
            email:userMessage.email,
            role:userMessage.role,
            state:userMessage.state
        })
        res.redirect("/users/user");
      }
    }else{
      //错误的密码
      res.redirect(`/users/user-edit?id=${userID}&message=密码验证错误`)
    }
    
}