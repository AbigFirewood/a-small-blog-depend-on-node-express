//用户主页渲染
const {Article}=require("../../model/artical")//文章集合构造函数
const {Comment} = require("../../model/comment")
const {Good}=require("../../model/good")
const mongoose =require("mongoose");
const getBecomment= async (id)=>{
    const articles = await Comment.find({}).populate("aid");
   return  articles.reduce((total,current)=>{
        if(current.aid.author.toString()==id.toString()){//对于id的比较必须使用字符串！！！否则会发生错误，使用的时候注意，toString 大写！
            return total+1;
        }else{
            return total;
        }
    },0)
}
const getBegood=async (id)=>{
    const goods= await Good.find({}).populate("aid");
    return goods.reduce((total,current)=>{
        if(current.aid.author.toString()==id.toString()){//对于id的比较必须使用字符串！！！否则会发生错误，使用的时候注意，toString 大写！
            return total+1;
        }else{
            return total;
        }
    },0)
}
module.exports=async function(req,res,next){
    req.app.locals.current="home";//标记高亮
    const articles = await Article.find({author  : req.app.locals.userInfo._id })//文章
    const comments = await Comment.countDocuments({uid  : req.app.locals.userInfo._id })//点赞数量
    const goods = await Good.countDocuments({uid  : req.app.locals.userInfo._id })//评论数量
    const views = articles.reduce((total,current)=>{//计算浏览量
        return total+current.view;
    },0)
    const beComment = await getBecomment( req.app.locals.userInfo._id);
    const begood = await getBegood(req.app.locals.userInfo._id);
    let  message ={articles : articles.length,comments,goods,views,beComment,begood }
    res.render("users/home", {message})
}
