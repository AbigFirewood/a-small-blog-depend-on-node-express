//文章删除
const {Article}=require("../../model/artical")//文章集合构造函数
const {Comment} = require("../../model/comment")
const {Good}=require("../../model/good")
module.exports=async function(req,res,next){
    Comment.remove({aid : req.query.id },(err)=>{if(err)console.log(err)})//文章的所有评论
    Good.remove({aid : req.query.id },(err)=>{if(err)console.log(err)})//文章的所有点赞
    await Article.findOneAndDelete({_id:req.query.id});
    res.redirect("/users/article");
}