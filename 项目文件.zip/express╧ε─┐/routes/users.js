//这个是管理员路由
var express = require('express');
var router = express.Router();
///从数据库模块导入用户集合构造函数
const {User}=require("../model/user");
//导入数据加密库bcriptjs 这个不需要任何依赖 用来比较密码
const bcrypt = require('bcryptjs');
///////////////////////////////////////////////////////////////////////////用户登录页面的实现
//下面的是渲染用户登录页面的路由 路径只写相对于路由器的相对路径就可以了
router.get('/login', function(req, res, next) {
  res.render("users/login")//提供相应的模板引擎渲染
});
//下面是相应用户登录请求的路由
router.post("/login" , require("./users/login.js"))
//实现用户退出的路由
router.get("/logout",require("./users/logout.js"))
//////////////////////////////////////////////////////////////////////////文章管理的实现
//下面的是文章修改页面渲染的路由
router.get('/article-edit', require("./users/article-edit-render"));
//文章列表渲染的路由
router.get("/article",require("./users/article-render"))
//文章添加路由
router.post("/article-add",require("./users/article-add"))
//文章删除路由
router.get("/article-delete",require("./users/article-delete"))
//文章修改路由
router.post("/article-edit",require("./users/article-edit"))
/////////////////////////////////////////////////////////////////////////用户管理的实现
//下面的是用户列表的路由
router.get('/user', require("./users/userpage"));
//下面是用户编辑页面渲染的路由
router.get("/user-edit",require("./users/user-edit-render"))
//下面是用户添加功能的路由相应的是用户编辑页面的post请求
router.post("/user-edit",require("./users/user-edit.js"))
//下面是用户信息修改功能的路由 响应对user-change 的post请求
router.post("/user-change",require("./users/user-change.js"))
//下面是用户删除的路由
router.get("/delete",require("./users/delete"))
///////////////////////////////////////////////////////////////////////用户首页路由
router.get("/home",require("./users/home-render.js"))
router.post("/head-edit",require("./users/head-edit"))
///////////////////////////////////////////////////////////////////////暴露路由

module.exports = router;
//路由器内部路径不需要写根路径