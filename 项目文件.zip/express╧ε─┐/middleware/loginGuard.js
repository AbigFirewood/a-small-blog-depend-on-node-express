const Guard = (req,res,next)=>{//拦截请求 从session中读取的
if(req.url!="/login"&&req.url.split("?")[0]!="/user-edit"&&!req.session.username){
          res.redirect("/users/login");
}else{
       if( req.session.role==="normal"&&req.url==="/user")
          return res.redirect(`/users/user-edit?id=${req.app.locals.userInfo._id}`)//res.send()}
        next();//必须"放行！！！
}}
module.exports=Guard;