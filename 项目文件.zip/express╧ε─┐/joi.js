const joi = require("joi")//引入
//定义验证规则
const schema =joi.object({
    username : joi.string().min(2).max(5).error(new Error("username 验证失败了")).required()//指定类型，然后指定内容
})
console.log(schema.validate({}));//验证