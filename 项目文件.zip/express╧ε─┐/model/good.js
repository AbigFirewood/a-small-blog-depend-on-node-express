//点赞处理集合
const {Schema, default: mongoose , model } = require("mongoose")
const goodSchema=new Schema({
    aid:{//文章id
        type : mongoose.Schema.Types.ObjectId,
        ref : "Article"//链接集合
    },uid:{//用户id
        type : mongoose.Schema.Types.ObjectId,
        ref: "User"
    },time:{//内容
        type : Date
    }
});
const Good = model("Good",goodSchema);
module.exports={
    Good
}