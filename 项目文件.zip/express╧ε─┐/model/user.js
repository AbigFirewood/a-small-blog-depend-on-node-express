//用户集合创建（注册用户）
//导入数据库控制元件
const mongoose =require("mongoose");
//导入数据加密库bcriptjs 这个不需要任何依赖
const bcrypt = require('bcryptjs')
//引入joi模块对用户信息进行验证
const joi = require("joi")
//建立一种集合模式（数据存储对象）
const userSchema=new mongoose.Schema({
    username :{
        type : String,//注意大写！！
        require:true,
        minlength:1,//最小长度 //maxlength:最大长度
    },
    email:{
        type : String,
        unique:true,//查重
        require:true
    },
    password:{
        type : String,
        require:true
    },
    role:{
        type : String,
        repuire:true
    },
    state:{
        type:Number,
        default:0
    },header:{
        type :String,
        default :"/home/images/logo.png"
    }
})

//获得一个集合的构造函数
const User = mongoose.model("User",userSchema);

//对用户信息进行初步验证
const validateUser=(user)=>{
    //定义对象验证规则
    const schema=joi.object({
        username:joi.string().min(1).error(new Error("用户名不符合规则！")).required(),
        email: joi.string().email().error(new Error("没有填写正确的邮箱格式！")).required(),
        password: joi.string().regex(/^[a-zA-Z0-9]{3,30}$/).error(new Error("密码必须由字母或者数字开头！")).required(),
        role:joi.string().valid("normal","admin").error(new Error("角色严重错误")).required(),
        state :joi.number().valid(0,1).error(new Error("状态非法")).required()
   })
   return schema.validate(user);
}
/*async function createUser(){
    const salt= await bcrypt.genSalt(10);
    const pass=await bcrypt.hash("nulixuexi88",salt)
    console.log()
    User.create({
        username:"nlxx88",
        email:"nlxx88@163.com",
        password: pass,
        role:"admin",
        state:0
    }).then(()=>console.log("管理员已经就位"))
    .catch(()=>console.log("初始化管理员失败"))
}
createUser();
*/

//建立一个集合（初始化管理员）
/*User.create({
    username:"nlxx88",
    email:"nlxx88@163.com",
    password:"nulixuexi88",
    role:"admin",
    state:0
}).then(()=>console.log("管理员已经就位"))
.catch(()=>console.log("初始化管理员失败"))
*/

//分别爆露
module.exports={
    User,
    validateUser
}