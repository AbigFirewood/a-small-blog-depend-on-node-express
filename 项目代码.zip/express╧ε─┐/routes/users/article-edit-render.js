//实现文章修改，新增的渲染工作
//引入文章集合构造类
const {Article}=require("../../model/artical")
module.exports= async function(req, res, next) {
    req.app.locals.current="art";//标记
    const {id} = req.query;
    if(id){
       let article = await Article.findOne({_id:id})
       res.render("users/article-edit",{article})//提供相应的模板引擎渲染
    }else{
       res.render("users/article-edit")//提供相应的模板引擎渲染
    }
  }