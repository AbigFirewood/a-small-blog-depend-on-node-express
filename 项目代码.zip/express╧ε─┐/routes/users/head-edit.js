const formidable = require("formidable")
const path = require("path");
const fs = require('fs');
const {User}=require("../../model/user")//文章集合构造函数
module.exports=async function(req,res,next){
    //res.send("fuck!")
    const {id} = req.query;
    const form = new formidable.IncomingForm();
    //配置服务器文件夹，将客户端上传的文件保存到这里这里必须写绝对路径 __dirname 是这个文件的文件夹
   form.uploadDir = path.join(__dirname,"../","../","public/","upload")
   //解系表单
   form.keepExtensions = true;
   form.parse(req,async function (err,fields,files){//错误对象 正常信息 文件信息
    fs.rename(path.normalize(files.cover.filepath),path.normalize(files.cover.filepath)+path.parse(files.cover.originalFilename).ext,(error)=>{if(error) {console.log(error)}})
     let thepath;
    if(path.parse(files.cover.originalFilename).ext===""){
        fs.unlink(path.normalize(files.cover.filepath),(err)=>{if(err)console.log("head-edit err in line 17")});
        thepath="/home/images/logo.png";
     }else{
        thepath= (path.normalize(files.cover.filepath)+path.parse(files.cover.originalFilename).ext).split("public")[1];
     }
        await User.updateOne({_id:id},{
          header:thepath
        })
        req.app.locals.userInfo.header = thepath;//更新一下渲染
    if(err){return console.log(err)}
      res.redirect("/users/home")//重定向  
      })
   }
