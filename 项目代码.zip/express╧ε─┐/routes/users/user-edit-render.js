const {User}=require("../../model/user")
module.exports=async function(req,res,next){
   req.app.locals.current="user";//标记,保持高亮的
    const {message , id }= req.query//如果出现了错误，会使用message提示
    if(id){//如果有id,证明是用户修改
       let user=await User.findOne({_id:id})//传递两个参数 错误信息 user信息
       res.render("users/user-edit", {message : message ,user:user } );
    }else{
       res.render("users/user-edit", {message : message });//传递一个错误信息
    }
  }