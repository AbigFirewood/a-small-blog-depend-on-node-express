//删除用户的路由
//导入数据库操作
const {User}=require("../../model/user");
const {Comment} = require("../../model/comment")
const {Good}=require("../../model/good")
const {Article}=require("../../model/artical")//文章集合构造函数
module.exports =async function(req,res,next){//使用get请求，信息会被携带在查询字符串中。通过req解析
   Comment.remove({uid : req.query.id },(err)=>{if(err)console.log(err)})//用户的所有评论
   Good.remove({uid : req.query.id },(err)=>{if(err)console.log(err)})//用户的所有点赞
   Article.remove({author: req.query.id },(err)=>{if(err)console.log(err)})//用户的所有文章
   await User.findOneAndDelete({_id:req.query.id});
   res.redirect("/users/user");
}