//文章请求
//引入第三方模块
const formidable = require("formidable")
const path = require("path");
const fs = require('fs');
const {Article}=require("../../model/artical")//文章集合构造函数
module.exports=async function(req,res,next){
    //建立表单解释对象
    const form = new formidable.IncomingForm();
    //配置服务器文件夹，将客户端上传的文件保存到这里这里必须写绝对路径 __dirname 是这个文件的文件夹
   form.uploadDir = path.join(__dirname,"../","../","public/","upload")
   //解系表单
   form.keepExtensions = true;
   form.parse(req,async function (err,fields,files){//错误对象 正常信息 文件信息
       fs.rename(path.normalize(files.cover.filepath),path.normalize(files.cover.filepath)+path.parse(files.cover.originalFilename).ext,(error)=>{if(error) {console.log(error)}})
       //由于保留文件后缀的操作蜜汁失灵，只能使用传统方法更改名字
     //res.send((path.normalize(files.cover.filepath)+path.parse(files.cover.originalFilename).ext).split("public")[1])
     let thepath;
     if(path.parse(files.cover.originalFilename).ext===""){
        thepath="/home/images/logo.png";
     }else{
        thepath= (path.normalize(files.cover.filepath)+path.parse(files.cover.originalFilename).ext).split("public")[1];
     }
      await Article.create({
        title :fields.title,
        author :fields.author,
        publishDate :fields.publishDate,
        content :fields.content,
        cover: thepath
      })
      if(err){return console.log(err)}
      res.redirect("/users/article")//重定向  
   })
}