//文章集合的查询
const {Article}=require("../../model/artical")
const pagenation = require("mongoose-sex-page")
module.exports=async function(req,res,next){
    req.app.locals.current="art";//标记,让标签可以高亮
    //查询所有文章数据
    //let articles = await Article.find({}).populate("author").lean();//这个项目关联了其他的数据库集合，所以可以使用这个方法进行多集和联合查询
    let select;
    if(req.app.locals.userInfo.role==="admin"){
        select={};
    }else{
        select={author  : req.app.locals.userInfo._id }
    }
    const {page} = req.query;
    let articles = await pagenation (Article).find(select).page(page).size(10).display(6).populate("author").exec(); 
    articles = JSON.stringify(articles);//不转化的话会报错，使用这种转换方法解决了报错问题，但是不知道为什么
    articles = JSON.parse(articles);
    res.render("users/article",{articles:articles});
}