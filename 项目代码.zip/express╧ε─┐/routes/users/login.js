const {User}=require("../../model/user");///从数据库模块导入用户集合构造函数
const bcrypt = require('bcryptjs');//导入数据加密库bcriptjs 这个不需要任何依赖 用来比较密码
module.exports=async (req,res)=>{
    //接受请求参数
   const {email,password}=req.body;
   if(email.trim().length===0||password.trim().length===0){
     return res.status(400).render("users/error",{msg:"邮件地址或密码错误!3S后跳转到原来页面，如果没有，请手动跳转"})
   }//对信息进行初步验证
   //查询用户信息 使用了await 语法 查到了user中就会有信息
   let user=await User.findOne({email : email})//使用findOne查询唯一的信息，只要集合中有这个信息项就会返回这个对象
   if(user){
     //查询到了用户
      if(user.state===0){
          let key=await bcrypt.compare(password,user.password);//实现比对密码
          if(key){
             req.session.username=user.username;//登录成功，向session中存储一些信息
             req.session.role=user.role;
            req.app.locals.userInfo = user;//在模板文件中存储一些信息，显示用户信息
             res.redirect("/") 
          }else{
             res.status(400).render("users/error",{msg:"用户名或者密码错误！"})
          }
      }else{
         res.status(400).render("users/error",{msg:"你的账号被封号了！！！"})
      }
   }else{ 
      res.status(400).render("users/error",{msg:"用户名或者密码错误！"}) 
  }
}
