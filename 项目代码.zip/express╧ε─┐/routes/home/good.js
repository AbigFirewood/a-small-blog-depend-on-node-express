//处理点赞数据的路由
const{Good}=require("../../model/good")
module.exports = async function(req,res,next){
      const {aid ,uid} = req.body;
      let find =await Good.findOne({uid : uid,aid:  aid})
      if(find){//取消赞
           await Good.findOneAndDelete({uid : uid , aid:  aid})
      }else{//增加赞
         await Good.create({
             uid :uid,
             aid :aid,
             time:new Date()
         })
      }
      res.redirect("/article?id="+aid);
}