const {Article} = require("../../model/artical")
const {Comment} = require("../../model/comment")
const {Good}=require("../../model/good")
module.exports =async function(req,res,next){
    const {id} = req.query;
    const article = await Article.findOne({_id:id}).populate("author").lean();//文章
    await Article.updateOne({_id:id},{view : article.view+1})//更新浏览量
    const comments = await Comment.find({aid:id}).populate("uid").lean();//评论
    const goods = await Good.countDocuments({aid:id});//评论
    let gooded = false;
    if( req.app.locals.userInfo){
        const find= await Good.countDocuments({aid:id , uid :req.app.locals.userInfo._id})
        if(find===1){
             gooded=true;
        }
    }
    //res.send(id);
    res.render("home/article.art",{article ,comments,goods,gooded})
}   