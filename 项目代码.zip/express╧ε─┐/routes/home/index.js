const {Article}=require("../../model/artical");//文章集合构造函数
//显示所有文章的界面
const pagination = require("mongoose-sex-page")
module.exports =async function(req,res,next){
    const {page} = req.query
    let result = await pagination(Article).find({}).page(page).size(4).display(3).populate("author").exec();
    result = JSON.stringify(result);//使用这种转换方法解决了报错问题，但是不知道为什么
    result = JSON.parse(result);
    res.render("home/default",{result:result})
}