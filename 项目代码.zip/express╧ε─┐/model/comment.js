const {Schema, default: mongoose , model } = require("mongoose")
const commentSchema=s=new Schema({
    aid:{//文章id
        type : mongoose.Schema.Types.ObjectId,
        ref : "Article"//链接集合
    },uid:{//用户id
        type : mongoose.Schema.Types.ObjectId,
        ref: "User"
    },content:{//时间
        type:String
    },time:{//内容
        type : Date
    }
});
const Comment = model("Comment",commentSchema);
module.exports={
    Comment
}