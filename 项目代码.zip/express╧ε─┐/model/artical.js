const mongoose =require("mongoose");
//建立集合规则 操作文章数据库
const articalSchema=new mongoose.Schema({
    title:{
        type : String,
        required:[true, "没有文章标题" ]
    },author:{
        type : mongoose.Schema.Types.ObjectId,//od
        ref: "User",//关联连个数据库,数据库的名字一定要写对！！！
        required:[true, "没有作者" ]
    },publishDate:{
        type : Date,
        required:[true,"没有时间"]
    },cover : {
        type :String,
        default :"/home/images/logo.png"
    },content:{
        type: String
    },view:{
        type :Number,
        default : 0
    }
}) 
const Article = mongoose.model("Article",articalSchema);//建立构造函数，第一个传入的参数将作为这个数据库集合的名字
 module.exports={Article}//暴露项目
