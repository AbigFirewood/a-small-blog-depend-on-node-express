var createError = require('http-errors');//错误处理
var express = require('express');//express
var path = require('path');//path模块
var cookieParser = require('cookie-parser');//cookie
var logger = require('morgan');//日志模块
const session =require("express-session");//session
var moment = require('moment');
    moment.locale('zh-cn');
const dataformat = require("dateformat");
const template = require("art-template");
template.defaults.imports.dateformat=dataformat;//模板导入
//数据库连接
require("./model/connect")

//下面是路由模块的导入
var indexRouter = require('./routes/home');
var usersRouter = require('./routes/users');
//建立一个express客户端
var app = express();

//添加的第三方模块处理post强求
const parser =require("body-parser");
app.use(parser.urlencoded({extended :false}))
//处理post请求,所有的post都被parser拦截了,这样的话所有的post请求都会多出来一个body项目

app.use(session({secret:"secret key",    //加密秘钥
                 saveUninitialized:false,//默认cookie
                cookie:{
                     maxAge:24*60*60*1000//过期时间毫秒
                }
         }))//配置session，实现用户识别
//托管静态资源
//需要使用完全路径，因此使用了path模块
//第一个参数是绝对根目录，第二个参数是之后的目录
//一定要在路由器之前托管静态资源！！！注意，html页面是视图模板，不是静态资源
app.use(express.static(path.join(__dirname,"public")));

// view engine setup 视图引擎设置
app.set('views', path.join(__dirname, 'views'));
//指示模板框架的位置
app.set('view engine', 'art');
//提供模板的默认后缀，让系统可以识别你的模板
app.engine("art",require("express-art-template"))
//需要先安装这个模板引擎，然后调用他

//下面是自动调用的几个中间件
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
//负责登录拦截
app.use("/users",require("./middleware/loginGuard.js"));
//使用的路由器
app.use('/', indexRouter);//对首页的访问
app.use('/users', usersRouter);//对用户已控制的访问

// catch 404 and forward to error handler 错误处理程序
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler 错误处理中间件
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error.jade');
});

//测试

module.exports = app; //让这个文件可以被使用
